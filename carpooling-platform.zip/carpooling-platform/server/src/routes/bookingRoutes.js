const express = require("express");
const router = express.Router();

const {
  createBooking,
  cancelBooking,
  getMyBookings,
  getMyBookingsForClient,
  getBookingsByRide,
  ratePassenger,
  rateDriver,
} = require("../controllers/bookingController");

const authMiddleware = require("../middlewares/authMiddleware");
const roleMiddleware = require("../middlewares/roleMiddleware");
const { body, param } = require("express-validator");
const { runValidation } = require("../middlewares/validationMiddleware");

// Passenger
router.post(
  "/",
  authMiddleware,
  roleMiddleware("passenger"),
  [
    body("rideId").isMongoId().withMessage("Valid rideId required"),
    body().custom((value) => {
      const seats = value?.seatsBooked ?? value?.numSeats;
      if (Number.isInteger(Number(seats)) && Number(seats) >= 1) return true;
      throw new Error("seatsBooked >= 1");
    }),
    body("passengerDetails").isObject().withMessage("Passenger details required for security"),
    body("passengerDetails.phone")
      .matches(/^\+?[0-9][0-9\s-]{8,14}$/)
      .withMessage("Valid passenger phone required"),
    body("passengerDetails.emergencyContactName")
      .isLength({ min: 2 })
      .withMessage("Emergency contact name required"),
    body("passengerDetails.emergencyContactPhone")
      .matches(/^\+?[0-9][0-9\s-]{8,14}$/)
      .withMessage("Valid emergency contact phone required"),
  ],
  runValidation,
  createBooking
);
router.get("/", authMiddleware, roleMiddleware("passenger"), getMyBookingsForClient);
router.get("/my", authMiddleware, roleMiddleware("passenger"), getMyBookings);
router.patch(
  "/:id/cancel",
  authMiddleware,
  roleMiddleware("passenger"),
  [param("id").isMongoId().withMessage("Valid booking id required")],
  runValidation,
  cancelBooking
);

// Driver
router.get(
  "/ride/:rideId",
  authMiddleware,
  roleMiddleware("driver"),
  getBookingsByRide
);

router.post(
  "/:id/rate",
  authMiddleware,
  roleMiddleware("passenger"),
  [param("id").isMongoId(), body("rating").isInt({ min: 1, max: 5 })],
  runValidation,
  rateDriver
);

router.post(
  "/rate/:bookingId",
  authMiddleware,
  roleMiddleware("driver"),
  [param("bookingId").isMongoId(), body("rating").isInt({ min: 1, max: 5 })],
  runValidation,
  ratePassenger
);

module.exports = router;

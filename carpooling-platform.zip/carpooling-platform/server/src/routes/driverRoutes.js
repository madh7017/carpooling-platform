const express = require("express");
const router = express.Router();
const authMiddleware = require("../middlewares/authMiddleware");
const roleMiddleware = require("../middlewares/roleMiddleware");
const { getDriverEarnings, getDriverDashboard } = require("../controllers/driverController");

router.get(
  "/dashboard",
  authMiddleware,
  roleMiddleware("driver"),
  getDriverDashboard
);

router.get(
  "/earnings",
  authMiddleware,
  roleMiddleware("driver"),
  getDriverEarnings
);

module.exports = router;

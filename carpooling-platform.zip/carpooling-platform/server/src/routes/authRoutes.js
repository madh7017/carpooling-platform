const express = require("express");
const router = express.Router();
const { body } = require("express-validator");
const { register, login, getMe } = require("../controllers/authController");
const { runValidation } = require("../middlewares/validationMiddleware");
const authMiddleware = require("../middlewares/authMiddleware");

router.post(
	"/register",
	[
		body("name").notEmpty().withMessage("Name is required"),
		body("email").isEmail().withMessage("Valid email required"),
		body("password").isLength({ min: 6 }).withMessage("Password min 6 chars"),
		body("role").optional().isIn(["driver", "passenger"]),
	],
	runValidation,
	register
);

router.post(
	"/login",
	[body("email").isEmail(), body("password").notEmpty()],
	runValidation,
	login
);

router.get("/me", authMiddleware, getMe);

module.exports = router;

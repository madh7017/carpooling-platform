const express = require("express");
const router = express.Router();
const authMiddleware = require("../middlewares/authMiddleware");
const roleMiddleware = require("../middlewares/roleMiddleware");
const { getPassengerDashboard } = require("../controllers/passengerController");

router.get(
  "/dashboard",
  authMiddleware,
  roleMiddleware("passenger"),
  getPassengerDashboard
);

module.exports = router;

const express = require("express");
const router = express.Router();

const {
  createRide,
  getRides,
  getRideById,
  completeRide,
  cancelRide,
  getMyRides,
  getDriverStats,
  getDriverEarnings,
} = require("../controllers/rideController");
const authMiddleware = require("../middlewares/authMiddleware");
const roleMiddleware = require("../middlewares/roleMiddleware");
const { body, query } = require("express-validator");
const { runValidation } = require("../middlewares/validationMiddleware");




// Public search rides
router.get(
  "/",
  [
    query("from").optional().isString(),
    query("to").optional().isString(),
    query("date").optional().isISO8601(),
    query("sortBy").optional().isIn(["price", "seats", "date"]),
    query("page").optional().isInt({ min: 1 }),
    query("limit").optional().isInt({ min: 1, max: 100 }),
  ],
  runValidation,
  getRides
);

// Driver dashboard - my rides
router.get(
  "/my",
  authMiddleware,
  roleMiddleware("driver"),
  getMyRides
);

// Driver stats (summary)
router.get(
  "/stats",
  authMiddleware,
  roleMiddleware("driver"),
  getDriverStats
);

// Driver earnings breakdown
router.get(
  "/earnings",
  authMiddleware,
  roleMiddleware("driver"),
  getDriverEarnings
);

// Compatibility alias for frontend
router.get("/search", getRides);

router.get("/:id", getRideById);



// Driver-only create ride
router.post(
  "/",
  authMiddleware,
  roleMiddleware("driver"),
  [
    body().custom((value) => {
      if (value?.source?.address || value?.from) return true;
      throw new Error("Source address required");
    }),
    body().custom((value) => {
      if (value?.destination?.address || value?.to) return true;
      throw new Error("Destination address required");
    }),
    body().custom((value) => {
      if (value?.dateTime) return true;
      if (value?.departureDate && value?.departureTime) return true;
      throw new Error("Valid dateTime required");
    }),
    body("pricePerSeat").isFloat({ min: 0 }).withMessage("Valid pricePerSeat required"),
    body().custom((value) => {
      const seats = value?.availableSeats ?? value?.totalSeats;
      if (Number.isInteger(Number(seats)) && Number(seats) >= 1) return true;
      throw new Error("availableSeats >= 1");
    }),
  ],
  runValidation,
  createRide
);

router.patch(
  "/:id/complete",
  authMiddleware,
  roleMiddleware("driver"),
  completeRide
);

router.patch(
  "/:id/cancel",
  authMiddleware,
  roleMiddleware("driver"),
  cancelRide
);



module.exports = router;

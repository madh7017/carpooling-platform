const Ride = require("../models/Ride");
const asyncHandler = require("../utils/asyncHandler");
const Booking = require("../models/Booking");

const formatRideForClient = (ride, totalSeatsOverride) => {
  const dateObj = new Date(ride.dateTime);
  const totalSeats =
    typeof totalSeatsOverride === "number"
      ? totalSeatsOverride
      : ride.availableSeats;

  return {
    ...ride.toObject(),
    from: ride.source?.address || "",
    to: ride.destination?.address || "",
    departureDate: dateObj.toISOString().split("T")[0],
    departureTime: dateObj.toTimeString().slice(0, 5),
    totalSeats,
  };
};

exports.createRide = asyncHandler(async (req, res) => {
  const {
    source,
    destination,
    dateTime,
    pricePerSeat,
    availableSeats,
    from,
    to,
    departureDate,
    departureTime,
    totalSeats,
  } = req.body;

  const normalizedSource = source?.address || from;
  const normalizedDestination = destination?.address || to;
  const normalizedDateTime =
    dateTime || (departureDate && departureTime ? new Date(`${departureDate}T${departureTime}`) : null);
  const normalizedAvailableSeats =
    availableSeats != null ? Number(availableSeats) : totalSeats != null ? Number(totalSeats) : null;

  if (
    !normalizedSource ||
    !normalizedDestination ||
    !normalizedDateTime ||
    pricePerSeat == null ||
    normalizedAvailableSeats == null
  ) {
    const error = new Error("Missing required ride fields");
    error.statusCode = 400;
    throw error;
  }

  if (normalizedAvailableSeats < 1) {
    const error = new Error("Available seats must be at least 1");
    error.statusCode = 400;
    throw error;
  }

  const ride = await Ride.create({
    driver: req.user.id,
    source: { address: normalizedSource },
    destination: { address: normalizedDestination },
    dateTime: normalizedDateTime,
    pricePerSeat,
    availableSeats: normalizedAvailableSeats,
  });

  res.status(201).json(formatRideForClient(ride, normalizedAvailableSeats));
});

exports.getRides = asyncHandler(async (req, res) => {
  const { from, to, date, sortBy, sort: querySort, page = 1, limit = 5, minPrice, maxPrice, minSeats } = req.query;

  const query = { status: "active" };

  if (from) query["source.address"] = { $regex: from, $options: "i" };
  if (to) query["destination.address"] = { $regex: to, $options: "i" };
  if (date) {
    const start = new Date(date);
    const end = new Date(date);
    end.setHours(23, 59, 59, 999);
    query.dateTime = { $gte: start, $lte: end };
  }
  if (minPrice != null || maxPrice != null) {
    query.pricePerSeat = {};
    if (minPrice != null && minPrice !== "") query.pricePerSeat.$gte = Number(minPrice);
    if (maxPrice != null && maxPrice !== "") query.pricePerSeat.$lte = Number(maxPrice);
  }
  if (minSeats != null && minSeats !== "") {
    query.availableSeats = { $gte: Number(minSeats) };
  }

  let sortConfig = { dateTime: 1 };
  const sortField = sortBy || querySort;
  if (sortField === "price") sortConfig = { pricePerSeat: 1 };
  if (sortField === "seats") sortConfig = { availableSeats: -1 };

  const skip = (page - 1) * limit;

  const [rides, total] = await Promise.all([
    Ride.find(query).populate("driver", "name rating").sort(sortConfig).skip(skip).limit(Number(limit)),
    Ride.countDocuments(query),
  ]);

  const rideIds = rides.map((ride) => ride._id);
  const seatAgg = await Booking.aggregate([
    { $match: { ride: { $in: rideIds }, status: { $in: ["confirmed", "completed"] } } },
    { $group: { _id: "$ride", bookedSeats: { $sum: "$seatsBooked" } } },
  ]);
  const bookedSeatsByRideId = new Map(seatAgg.map((item) => [item._id.toString(), item.bookedSeats]));

  const formattedRides = rides.map((ride) => {
    const bookedSeats = bookedSeatsByRideId.get(ride._id.toString()) || 0;
    const totalSeats = ride.availableSeats + bookedSeats;
    return formatRideForClient(ride, totalSeats);
  });

  res.json({
    rides: formattedRides,
    total,
    page: Number(page),
    pages: Math.ceil(total / limit),
  });
});

exports.getRideById = asyncHandler(async (req, res) => {
  const ride = await Ride.findById(req.params.id).populate("driver", "name rating");
  if (!ride) {
    return res.status(404).json({ message: "Ride not found" });
  }

  const seatAgg = await Booking.aggregate([
    { $match: { ride: ride._id, status: { $in: ["confirmed", "completed"] } } },
    { $group: { _id: "$ride", bookedSeats: { $sum: "$seatsBooked" } } },
  ]);
  const bookedSeats = seatAgg[0]?.bookedSeats || 0;
  const totalSeats = ride.availableSeats + bookedSeats;

  res.json({ ride: formatRideForClient(ride, totalSeats) });
});

exports.completeRide = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const ride = await Ride.findById(id);
  if (!ride) {
    const err = new Error("Ride not found");
    err.statusCode = 404;
    throw err;
  }

  if (ride.driver.toString() !== req.user.id) {
    const err = new Error("Not authorized to complete this ride");
    err.statusCode = 403;
    throw err;
  }

  if (ride.status !== "active") {
    const err = new Error("Ride is not active");
    err.statusCode = 400;
    throw err;
  }

  ride.status = "completed";
  await Promise.all([
    ride.save(),
    Booking.updateMany({ ride: ride._id, status: "confirmed" }, { status: "completed" }),
  ]);

  res.json({ message: "Ride marked as completed" });
});

exports.cancelRide = asyncHandler(async (req, res) => {
  const ride = await Ride.findById(req.params.id);
  if (!ride) {
    const error = new Error("Ride not found");
    error.statusCode = 404;
    throw error;
  }

  if (ride.driver.toString() !== req.user.id) {
    const error = new Error("Not authorized to cancel this ride");
    error.statusCode = 403;
    throw error;
  }

  ride.status = "cancelled";
  await ride.save();

  await Booking.updateMany({ ride: ride._id, status: "confirmed" }, { status: "cancelled" });

  res.json({ message: "Ride cancelled and all bookings updated" });
});

exports.getMyRides = asyncHandler(async (req, res) => {
  const rides = await Ride.find({ driver: req.user.id }).sort({ createdAt: -1 });
  res.json(rides);
});

exports.getDriverStats = asyncHandler(async (req, res) => {
  const rides = await Ride.find({ driver: req.user.id });
  const rideIds = rides.map((r) => r._id);

  const bookings = await Booking.find({ ride: { $in: rideIds }, status: "confirmed" }).populate("ride");

  const totalEarnings = bookings.reduce((sum, b) => sum + b.seatsBooked * b.ride.pricePerSeat, 0);

  res.json({
    totalRides: rides.length,
    totalBookings: bookings.length,
    totalEarnings,
  });
});

exports.getDriverEarnings = asyncHandler(async (req, res) => {
  const rides = await Ride.find({ driver: req.user.id });
  const rideIds = rides.map((r) => r._id);

  const bookings = await Booking.find({ ride: { $in: rideIds }, status: "confirmed" }).populate("ride");

  const earningsByRide = {};

  bookings.forEach((b) => {
    const rideId = b.ride._id.toString();
    if (!earningsByRide[rideId]) {
      earningsByRide[rideId] = {
        rideId,
        from: b.ride.source.address,
        to: b.ride.destination.address,
        dateTime: b.ride.dateTime,
        pricePerSeat: b.ride.pricePerSeat,
        seatsBooked: 0,
        earnings: 0,
        status: b.ride.status,
      };
    }

    earningsByRide[rideId].seatsBooked += b.seatsBooked;
    earningsByRide[rideId].earnings += b.seatsBooked * b.ride.pricePerSeat;
  });

  res.json(Object.values(earningsByRide));
});
 

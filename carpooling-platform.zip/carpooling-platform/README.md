# CarPool Platform 🚗

A production-ready full-stack carpooling application built with MERN stack (MongoDB, Express, React, Node.js).

> Recently improved with enhanced error handling, security configurations, and comprehensive documentation. See [IMPROVEMENTS.md](IMPROVEMENTS.md) for details.

## 📋 Table of Contents
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Documentation](#documentation)
- [Development](#development)
- [API Endpoints](#api-endpoints)
- [Troubleshooting](#troubleshooting)

## Features

### For Passengers
- 🔍 Search and filter rides by location, date, price, and available seats
- 📅 Book rides with seat selection
- 💰 View booking history and pricing
- ⭐ Rate drivers and leave reviews
- 📊 Dashboard with booking statistics

### For Drivers
- 🚗 Create and manage rides
- 📍 Set departure locations, times, and prices
- 👥 View passenger details per ride
- 💵 Track earnings and analytics
- ⭐ View passenger ratings
- 📊 Comprehensive driver dashboard

### Security & Authentication
- 🔐 JWT-based authentication with token refresh
- 🔒 Password hashing with bcrypt (12 salt rounds)
- 🛡️ Role-based access control
- ✅ Protected API endpoints
- 🚫 Automatic 401 error handling
- 🔐 Environment-based configuration

## Tech Stack

### Frontend
- **React 18** - Modern UI with hooks
- **Vite** - Lightning-fast build tool
- **React Router v6** - Client-side routing
- **Axios** - HTTP client with interceptors
- **Tailwind CSS** - Utility-first styling
- **ESLint** - Code quality

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **MongoDB** - NoSQL database
- **Mongoose** - Database ODM
- **JWT** - Authentication tokens
- **bcryptjs** - Secure password hashing
- **express-validator** - Input validation

## Installation

### Prerequisites
- **Node.js** 16+ and npm 8+
- **MongoDB** 4.4+ (local or [Atlas Cloud](https://www.mongodb.com/cloud/atlas))
- **Git** (for version control)

### Quick Setup (Automatic)

#### Windows
```bash
cd carpooling-platform
install.bat
```

#### Linux/Mac  
```bash
cd carpooling-platform
chmod +x install.sh
./install.sh
```

#### Manual Setup
```bash
cd carpooling-platform
node install.js
```

### Manual Installation Step-by-Step

#### 1. Setup Server
```bash
cd server
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm install
```

#### 2. Setup Client
```bash
cd ../client
cp .env.example .env.local
npm install
```

#### 3. Configure Database
**Option A: Local MongoDB**
```bash
mongod
```

**Option B: MongoDB Atlas (Cloud)**
1. Create account at https://www.mongodb.com/cloud/atlas
2. Create a database cluster
3. Get connection string
4. Update `MONGO_URI` in `server/.env`

## Quick Start

### Start Development Servers

#### Terminal 1 - Backend
```bash
cd server
npm run dev
# Server running on http://localhost:5000
# API available at http://localhost:5000/api
# Health check: http://localhost:5000/api/health
```

#### Terminal 2 - Frontend
```bash
cd client
npm run dev
# App running on http://localhost:5173
```

#### Open in Browser
```
http://localhost:5173
```

## Documentation

### 📖 Essential Guides
- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Detailed installation instructions
- **[DEVELOPMENT.md](DEVELOPMENT.md)** - Development workflow and project structure
- **[IMPROVEMENTS.md](IMPROVEMENTS.md)** - Recent enhancements and changes

### 🔒 Security
- Environment variables protect credentials
- Passwords hashed with bcryptjs (12 rounds)
- JWT tokens with configurable expiration
- Request validation and sanitization
- Error messages don't expose internals
- Automatic unauthorized user redirect

### 📝 Code Quality
- ESLint rules for frontend and backend
- Prettier code formatting
- Consistent error handling
- Comprehensive validation
- Type-safe error responses

## Development

### Project Structure
```
carpooling-platform/
├── client/                 # React frontend application
├── server/                 # Express backend API
├── .env.example           # Environment template
├── .gitignore             # Git ignore rules  
├── .prettierrc.json       # Code formatter config
├── README.md              # This file
├── SETUP_GUIDE.md         # Installation guide
├── DEVELOPMENT.md         # Development guide
└── IMPROVEMENTS.md        # Recent improvements
```

### Development Scripts

#### Frontend
```bash
cd client
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
```

#### Backend
```bash
cd server
npm run dev          # Start with hot reload (nodemon)
npm start            # Start production server
npm run lint         # Run ESLint
npm run lint:fix     # Fix linting errors
```

### Environment Configuration
All configuration is environment-based for security:

#### Server Environment (`.env`)
```env
MONGO_URI=mongodb://localhost:27017/carpooling
JWT_SECRET=your_super_secret_key_min_32_chars
JWT_EXPIRES_IN=7d
PORT=5000
NODE_ENV=development
CORS_ORIGIN=http://localhost:5173
```

#### Client Environment (`.env.local`)
```env
VITE_API_BASE_URL=http://localhost:5000/api
VITE_NODE_ENV=development
```

## API Endpoints

### Authentication
```
POST   /api/auth/register      - Register new user
POST   /api/auth/login         - Login user
```

### Rides
```
GET    /api/rides              - List all rides
GET    /api/rides/:id          - Get ride details
POST   /api/rides              - Create ride (driver only)
PUT    /api/rides/:id          - Update ride (driver only)
DELETE /api/rides/:id          - Delete ride (driver only)
```

### Bookings
```
GET    /api/bookings           - User's bookings
GET    /api/bookings/:id       - Booking details
POST   /api/bookings           - Create booking
PUT    /api/bookings/:id       - Update booking status
DELETE /api/bookings/:id       - Cancel booking
```

### Users
```
GET    /api/drivers/:id        - Driver profile & stats
GET    /api/passengers/:id     - Passenger profile
```

## Features by Role

### 👤 Passenger Features
- ✅ Register and login
- ✅ Search available rides
- ✅ Book seats on rides
- ✅ View booking history
- ✅ Cancel bookings
- ✅ Rate and review drivers
- ✅ Dashboard with trip statistics

### 🚗 Driver Features
- ✅ Register and login
- ✅ Create new rides
- ✅ Set price per seat
- ✅ Manage ride availability
- ✅ View passenger details
- ✅ Track earnings
- ✅ View passenger ratings
- ✅ Dashboard with analytics

## Troubleshooting

### Server won't start
**Problem**: Port 5000 already in use
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac
lsof -i :5000
kill -9 <PID>
```

### MongoDB connection failed
**Problem**: `MONGO_URI` not set or invalid
- Check `.env` file exists in server folder
- Verify MongoDB is running (`mongod`)
- Check connection string format
- Use MongoDB Compass to test connection

### CORS errors
**Problem**: Frontend can't reach backend
- Verify API URL in `client/.env.local`
- Check `CORS_ORIGIN` in `server/.env`
- Ensure backend is running on port 5000
- Restart both servers

### Authentication issues  
**Problem**: Login fails or stays logged out
```javascript
// Clear browser storage
localStorage.clear()
sessionStorage.clear()
```
- Check JWT_SECRET in `.env`
- Verify token in Network tab headers
- Check user exists in database

### Build errors
**Problem**: `npm install` fails
```bash
# Delete and reinstall
rm -rf node_modules
npm install
```

## Common Commands Reference

```bash
# Installation
npm install                    # Install dependencies

# Development
npm run dev                   # Start dev server
npm run lint                  # Check code quality
npm run lint:fix              # Auto-fix code style

# Production
npm run build                 # Create production build
npm start                     # Run production server
npm run preview              # Preview production build

# Database
mongod                        # Start MongoDB (if installed locally)
```

## Performance Tips

### Frontend
- Lazy load routes with React.lazy()
- Use React.memo for expensive components
- Optimize images before uploading
- Enable gzip compression

### Backend
- Add database indexes for frequent queries
- Implement pagination for large datasets
- Use lean() for read-only queries
- Cache frequently accessed data

## Security Checklist

- ✅ Environment variables for credentials
- ✅ Password hashing enabled
- ✅ JWT authentication implemented
- ✅ CORS configured
- ✅ Error handling doesn't expose internals
- ⚠️ TODO: Add rate limiting
- ⚠️ TODO: Add HTTPS/SSL
- ⚠️ TODO: Add security headers (Helmet.js)

## Future Enhancements

- [ ] Real-time notifications with Socket.io
- [ ] Payment integration (Stripe)
- [ ] Email verification
- [ ] Two-factor authentication
- [ ] Ride tracking with maps (Google Maps API)
- [ ] Advanced search filters
- [ ] In-app messaging system
- [ ] Rating and review system with photos
- [ ] Admin dashboard
- [ ] Analytics and reporting

## Contributing

1. Create a feature branch: `git checkout -b feature/your-feature`
2. Make your changes
3. Run linting: `npm run lint`
4. Commit: `git commit -m "feat: description"`
5. Push: `git push origin feature/your-feature`
6. Create a Pull Request

## Resources

- [React Documentation](https://react.dev)
- [Express.js Guide](https://expressjs.com)
- [MongoDB Manual](https://docs.mongodb.com/manual/)
- [Tailwind CSS](https://tailwindcss.com)
- [Vite Guide](https://vitejs.dev)
- [JWT Introduction](https://jwt.io)
- [RESTful API Design](https://restfulapi.net)

## Support

For issues or questions:
1. Check the [SETUP_GUIDE.md](SETUP_GUIDE.md)
2. Check the [DEVELOPMENT.md](DEVELOPMENT.md)
3. Review the [IMPROVEMENTS.md](IMPROVEMENTS.md)
4. Open an issue with detailed information

## License

MIT License - feel free to use this project for learning and development.

## Acknowledgments

- MongoDB for the excellent database
- React team for amazing UI framework
- Express.js community for excellent documentation
- Tailwind CSS for utility-first styling approach

---

**Happy coding! 🚀**

*Last Updated: 2026*
*Version: 1.0.0-improved*

## Features

### For Passengers
- 🔍 Search and filter rides by location, date, price, and available seats
- 📅 Book rides with seat selection
- 💰 View booking history and pricing
- ⭐ Rate drivers and leave reviews
- 📊 Dashboard with booking statistics

### For Drivers
- 🚗 Create and manage rides
- 📍 Set departure locations, times, and prices
- 👥 View passenger details per ride
- 💵 Track earnings and analytics
- ⭐ View passenger ratings
- 📊 Comprehensive driver dashboard

### Security & Authentication
- 🔐 JWT-based authentication
- 🔒 Password hashing with bcrypt
- 🛡️ Role-based access control
- ✅ Protected API endpoints
- 🚫 Prevent duplicate bookings

## Tech Stack

### Frontend
- **React 18** - UI framework
- **Vite** - Build tool
- **React Router** - Navigation
- **Axios** - API client
- **Tailwind CSS** - Styling

### Backend
- **Node.js** - Runtime
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **JWT** - Authentication
- **bcryptjs** - Password hashing

## Installation

### Prerequisites
- Node.js 16+ and npm
- MongoDB 4.4+ (local or Atlas)
- Git

### Quick Setup (Automatic)

#### Windows
```bash
cd carpooling-platform
install.bat
```

#### Linux/Mac
```bash
cd carpooling-platform
chmod +x install.sh
./install.sh
```

#### Manual Setup (Node.js script)
```bash
cd carpooling-platform
node install.js
```

### Manual Installation

1. **Install Client Dependencies**
```bash
cd client
npm install
```

2. **Install Server Dependencies**
```bash
cd server
npm install
```

3. **Setup Environment Variables**
```bash
cd server
# Create .env file with:
MONGO_URI=mongodb://localhost:27017/carpooling
JWT_SECRET=your_secure_secret_key
JWT_EXPIRE=7d
PORT=5000
NODE_ENV=development
```

4. **Start MongoDB**
```bash
# Make sure MongoDB is running
mongod
```

5. **Start Backend**
```bash
cd server
npm run dev
# Server running on http://localhost:5000
```

6. **Start Frontend** (new terminal)
```bash
cd client
npm run dev
# App running on http://localhost:5173
```

## Project Structure

```
carpooling-platform/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/          # Page components
│   │   ├── context/        # React context
│   │   ├── services/       # API services
│   │   └── App.jsx         # Main app
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── server/                 # Express backend
│   ├── models/             # MongoDB schemas
│   ├── routes/             # API routes
│   ├── middleware/         # Custom middleware
│   ├── server.js           # Entry point
│   └── .env                # Environment variables
│
└── README.md               # This file
```

## API Documentation

### Authentication Routes
```
POST   /api/auth/register    - Register new user
POST   /api/auth/login       - Login user
GET    /api/auth/me          - Get current user
```

### Ride Routes
```
POST   /api/rides            - Create new ride (driver only)
GET    /api/rides/search     - Search rides with filters
GET    /api/rides/:rideId    - Get ride details
PATCH  /api/rides/:rideId/complete - Mark ride completed
PATCH  /api/rides/:rideId/cancel   - Cancel ride
```

### Booking Routes
```
POST   /api/bookings         - Create booking (passenger only)
GET    /api/bookings         - Get user bookings
PATCH  /api/bookings/:id/cancel - Cancel booking
POST   /api/bookings/:id/rate    - Rate driver
```

### Dashboard Routes
```
GET    /api/passengers/dashboard  - Passenger stats
GET    /api/drivers/dashboard     - Driver stats
```

## Usage

### Register
1. Click "Register" on homepage
2. Fill in name, email, phone, and password
3. Choose role (Passenger or Driver)
4. Submit

### Search Rides (Passenger)
1. Go to "Search Rides"
2. Filter by location, date, price, seats
3. Click "View Details" on a ride
4. Select number of seats and book

### Create Ride (Driver)
1. Go to "Create Ride"
2. Fill in departure location, destination, date, time
3. Set number of seats and price per seat
4. Submit

### Rate Drivers (Passenger)
1. Go to "My Bookings"
2. Find completed rides
3. Click "Rate Driver"
4. Submit rating and review

## Environment Variables

### Server (.env)
```
MONGO_URI          # MongoDB connection string
JWT_SECRET         # Secret key for JWT tokens
JWT_EXPIRE         # Token expiration time (e.g., 7d)
PORT               # Server port (default: 5000)
NODE_ENV           # Environment (development/production)
```

## Scripts

### Frontend
```bash
npm run dev        # Start dev server
npm run build      # Build for production
npm run preview    # Preview production build
```

### Backend
```bash
npm run dev        # Start with nodemon
npm start          # Start server
```

## Security Considerations

- ✅ Passwords hashed with bcrypt
- ✅ JWT tokens for secure authentication
- ✅ Role-based access control
- ✅ Input validation on backend
- ✅ Protected API endpoints
- ✅ Environment variables for sensitive data

⚠️ **Before production deployment:**
- Change JWT_SECRET to a strong random key
- Enable HTTPS
- Set NODE_ENV to production
- Configure CORS properly
- Add rate limiting
- Enable MongoDB authentication

## Troubleshooting

### MongoDB Connection Error
```
Make sure MongoDB is running:
- Local: mongod
- Atlas: Check connection string in .env
```

### Port Already in Use
```
Port 5000 (backend):
- Change PORT in .env or
- Kill process: lsof -ti:5000 | xargs kill -9

Port 5173 (frontend):
- Vite will use next available port
```

### Node Modules Issues
```
# Clear and reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### CORS Errors
```
Check that backend is running on http://localhost:5000
and frontend proxy is configured in vite.config.js
```

## Future Enhancements

- 🗺️ Google Maps integration for routes
- 💳 Payment gateway integration
- 📱 Mobile app (React Native)
- 🔔 Real-time notifications
- 💬 In-app messaging
- 📍 GPS tracking
- 🎯 Advanced analytics
- 🌍 Multi-language support

## Contributing

Contributions welcome! Please follow these steps:
1. Fork the repository
2. Create a feature branch
3. Commit changes
4. Push to branch
5. Open a pull request

## License

MIT License - feel free to use this project

## Support

For issues and questions:
- Open an issue on GitHub
- Check existing documentation
- Review error messages carefully

---

Built with ❤️ by CarPool Team

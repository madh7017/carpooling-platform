export const formatINR = (value) => {
  const amount = Number(value || 0);
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDateIN = (value) => {
  if (!value) return "";
  return new Date(value).toLocaleDateString("en-IN");
};

import { useState, useEffect, useMemo } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '@context/AuthContext'
import Loading from '@components/Loading'
import { formatINR } from '@utils/formatters'

const getStatusMeta = (status) => {
  if (status === 'active') {
    return {
      label: 'Live ride tracking enabled',
      tone: 'success',
      note: 'Ride is active. Share your trip link with trusted contacts and keep emergency call access ready.',
    }
  }

  if (status === 'completed') {
    return {
      label: 'Ride completed',
      tone: 'info',
      note: 'Trip has ended. Please rate your experience to improve safety for future riders.',
    }
  }

  return {
    label: 'Ride cancelled',
    tone: 'danger',
    note: 'This trip is no longer active. Please book another verified ride.',
  }
}

const RideDetail = () => {
  const { rideId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [ride, setRide] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [selectedSeats, setSelectedSeats] = useState(1)
  const [booking, setBooking] = useState(false)
  const [passengerDetails, setPassengerDetails] = useState({
    phone: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    note: '',
  })

  useEffect(() => {
    const fetchRide = async () => {
      try {
        const response = await axios.get(`/api/rides/${rideId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        })
        setRide(response.data.ride)
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch ride')
      } finally {
        setLoading(false)
      }
    }

    fetchRide()
  }, [rideId])

  const handleBookRide = async () => {
    if (!user) {
      navigate('/login')
      return
    }

    if (user.role !== 'passenger') {
      setError('Only passengers can book rides')
      return
    }

    if (
      !passengerDetails.phone.trim() ||
      !passengerDetails.emergencyContactName.trim() ||
      !passengerDetails.emergencyContactPhone.trim()
    ) {
      setError('Please fill passenger and emergency contact details for safety')
      return
    }

    try {
      setBooking(true)
      await axios.post(
        `/api/bookings`,
        { rideId, numSeats: selectedSeats, passengerDetails },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      )
      alert('Ride booked successfully!')
      navigate('/my-bookings')
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed')
    } finally {
      setBooking(false)
    }
  }

  const mapLinks = useMemo(() => {
    if (!ride) return null

    const from = ride.from || ride.source?.address || ''
    const to = ride.to || ride.destination?.address || ''
    const query = encodeURIComponent(`${from} to ${to}`)

    return {
      embed: `https://www.google.com/maps?q=${query}&output=embed&hl=en&gl=IN`,
      googleDirections: `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(from)}&destination=${encodeURIComponent(to)}&travelmode=driving&hl=en&gl=IN`,
      osmSearch: `https://www.openstreetmap.org/search?query=${query}`,
    }
  }, [ride])

  if (loading) return <Loading />

  if (!ride) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <p className="text-red-600">{error || 'Ride not found'}</p>
      </div>
    )
  }

  const statusMeta = getStatusMeta(ride.status)

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      <div className="card">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold mb-2">{ride.from} to {ride.to}</h1>
            <span className={`badge badge-${ride.status === 'active' ? 'success' : ride.status === 'completed' ? 'info' : 'danger'}`}>
              {ride.status}
            </span>
          </div>
          <a href={mapLinks.googleDirections} target="_blank" rel="noreferrer" className="btn-outline">
            Open Navigation
          </a>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h3 className="text-xl font-bold mb-4">Trip Details</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-gray-600">Date and Time</p>
                <p className="font-semibold">
                  {new Date(ride.departureDate).toLocaleDateString('en-IN')} at {ride.departureTime}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-gray-600">Fare per Seat</p>
                <p className="font-semibold">{formatINR(ride.pricePerSeat)}</p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-gray-600">Available Seats</p>
                <p className="font-semibold">{ride.availableSeats}/{ride.totalSeats}</p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-gray-600">Car Model</p>
                <p className="font-semibold">{ride.carModel || 'Not specified'}</p>
              </div>
            </div>

            <h3 className="text-xl font-bold mt-8 mb-4">Driver Info</h3>
            <div className="rounded-xl border border-slate-200 p-4 space-y-2">
              <p><strong>Name:</strong> {ride.driver.name}</p>
              <p><strong>Rating:</strong> {ride.driver.rating || 'No ratings yet'}</p>
              <p><strong>Phone:</strong> {ride.driver.phone || 'Not shared'}</p>
            </div>
          </div>

          {user?.role === 'passenger' && ride.status === 'active' && (
            <div className="bg-blue-50 p-6 rounded-lg h-fit">
              <h3 className="text-xl font-bold mb-4">Book This Ride</h3>

              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-3 py-2 rounded mb-4 text-sm">
                  {error}
                </div>
              )}

              <div className="mb-4">
                <label className="block text-gray-700 font-semibold mb-2">Number of Seats</label>
                <select
                  value={selectedSeats}
                  onChange={(e) => setSelectedSeats(parseInt(e.target.value, 10))}
                  disabled={ride.availableSeats === 0}
                  className="input-field"
                >
                  {Array.from({ length: Math.min(ride.availableSeats, 5) }, (_, i) => i + 1).map((num) => (
                    <option key={num} value={num}>
                      {num} {num === 1 ? 'Seat' : 'Seats'}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-3 mb-4">
                <p className="text-sm font-semibold text-gray-700">Passenger Safety Details</p>
                <input
                  type="tel"
                  className="input-field"
                  placeholder="Your phone number (+91...)"
                  value={passengerDetails.phone}
                  onChange={(e) => setPassengerDetails((prev) => ({ ...prev, phone: e.target.value }))}
                  disabled={booking}
                />
                <input
                  type="text"
                  className="input-field"
                  placeholder="Emergency contact name"
                  value={passengerDetails.emergencyContactName}
                  onChange={(e) =>
                    setPassengerDetails((prev) => ({ ...prev, emergencyContactName: e.target.value }))
                  }
                  disabled={booking}
                />
                <input
                  type="tel"
                  className="input-field"
                  placeholder="Emergency contact phone (+91...)"
                  value={passengerDetails.emergencyContactPhone}
                  onChange={(e) =>
                    setPassengerDetails((prev) => ({ ...prev, emergencyContactPhone: e.target.value }))
                  }
                  disabled={booking}
                />
                <textarea
                  className="textarea-field"
                  placeholder="Optional safety note (medical, pickup preference, etc.)"
                  value={passengerDetails.note}
                  onChange={(e) => setPassengerDetails((prev) => ({ ...prev, note: e.target.value }))}
                  disabled={booking}
                />
              </div>

              <div className="bg-white p-3 rounded mb-4 border">
                <div className="flex justify-between mb-2">
                  <span>Base fare:</span>
                  <span>{formatINR(ride.pricePerSeat * selectedSeats)}</span>
                </div>
                <div className="border-t pt-2">
                  <div className="flex justify-between font-bold">
                    <span>Total:</span>
                    <span>{formatINR(ride.pricePerSeat * selectedSeats)}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleBookRide}
                disabled={booking || ride.availableSeats === 0}
                className="w-full btn-primary disabled:opacity-50"
              >
                {booking ? 'Booking...' : ride.availableSeats === 0 ? 'No Seats Available' : 'Book Now'}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <h2 className="heading-4">Safety Tracking Map</h2>
          <span className={`badge badge-${statusMeta.tone}`}>{statusMeta.label}</span>
        </div>

        <p className="text-muted mb-4">{statusMeta.note}</p>

        <div className="overflow-hidden rounded-xl border border-slate-200 h-80">
          <iframe
            title="Ride route map"
            src={mapLinks.embed}
            width="100%"
            height="100%"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>

        <div className="mt-4 flex flex-wrap gap-3">
          <a href={mapLinks.googleDirections} target="_blank" rel="noreferrer" className="btn-secondary">
            Google Maps Directions
          </a>
          <a href={mapLinks.osmSearch} target="_blank" rel="noreferrer" className="btn-secondary">
            OpenStreetMap View
          </a>
          <a href="tel:112" className="btn-danger">
            Emergency (112)
          </a>
        </div>
      </div>
    </div>
  )
}

export default RideDetail

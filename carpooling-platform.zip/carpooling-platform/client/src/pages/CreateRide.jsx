import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const CreateRide = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    from: "",
    to: "",
    departureDate: "",
    departureTime: "",
    carModel: "",
    totalSeats: 4,
    pricePerSeat: 250,
    notes: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: ["totalSeats", "pricePerSeat"].includes(name) ? parseInt(value) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.from || !formData.to || !formData.departureDate || !formData.departureTime) {
      setError("Please fill in all required fields");
      return;
    }

    try {
      setLoading(true);
      await axios.post("/api/rides", formData, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      alert("Ride created successfully!");
      navigate("/driver-dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to create ride");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Create a New Ride</h1>

      <div className="bg-white rounded-lg shadow-md p-8">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block font-semibold mb-2">From *</label>
              <input
                type="text"
                name="from"
                value={formData.from}
                onChange={handleChange}
                placeholder="Starting city (e.g., Bengaluru)"
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">To *</label>
              <input
                type="text"
                name="to"
                value={formData.to}
                onChange={handleChange}
                placeholder="Destination city (e.g., Chennai)"
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">Departure Date *</label>
              <input
                type="date"
                name="departureDate"
                value={formData.departureDate}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">Departure Time *</label>
              <input
                type="time"
                name="departureTime"
                value={formData.departureTime}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">Car Model</label>
              <input
                type="text"
                name="carModel"
                value={formData.carModel}
                onChange={handleChange}
                placeholder="e.g., Maruti Suzuki Ertiga"
                className="input-field"
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">Total Seats</label>
              <input
                type="number"
                name="totalSeats"
                value={formData.totalSeats}
                onChange={handleChange}
                min="1"
                max="8"
                className="input-field"
              />
            </div>

            <div>
              <label className="block font-semibold mb-2">Fare per Seat (INR)</label>
              <input
                type="number"
                name="pricePerSeat"
                value={formData.pricePerSeat}
                onChange={handleChange}
                min="0"
                step="1"
                className="input-field"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-2">Additional Notes</label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="e.g., Pickup near metro station, one luggage per rider"
              rows="4"
              className="input-field"
            ></textarea>
          </div>

          <div className="flex gap-4">
            <button type="submit" disabled={loading} className="btn-primary disabled:opacity-50">
              {loading ? "Creating..." : "Create Ride"}
            </button>
            <button type="button" onClick={() => navigate("/driver-dashboard")} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateRide;

import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '@context/AuthContext'
import Loading from '@components/Loading'
import { formatINR } from '@utils/formatters'

const SearchRides = () => {
  const { user } = useAuth()
  const [filters, setFilters] = useState({
    from: '',
    to: '',
    date: '',
    minPrice: '',
    maxPrice: '',
    minSeats: '',
  })
  const [rides, setRides] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [sortBy, setSortBy] = useState('date')
  const [page, setPage] = useState(1)

  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters((prev) => ({ ...prev, [name]: value }))
    setPage(1)
  }

  const handleSearch = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const params = new URLSearchParams()
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value)
      })
      params.append('sort', sortBy)
      params.append('page', page)
      params.append('limit', 10)

      const response = await axios.get(`/api/rides/search?${params}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setRides(response.data.rides)
    } catch (err) {
      setError(err.response?.data?.message || 'Search failed')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    handleSearch({ preventDefault: () => {} })
  }, [])

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Search Rides Across India</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <form onSubmit={handleSearch} className="grid md:grid-cols-3 gap-4">
          <input
            type="text"
            name="from"
            placeholder="From city (e.g., Bengaluru)"
            value={filters.from}
            onChange={handleFilterChange}
            className="input-field"
          />

          <input
            type="text"
            name="to"
            placeholder="To city (e.g., Chennai)"
            value={filters.to}
            onChange={handleFilterChange}
            className="input-field"
          />

          <input
            type="date"
            name="date"
            value={filters.date}
            onChange={handleFilterChange}
            className="input-field"
          />

          <input
            type="number"
            name="minPrice"
            placeholder="Min Fare (INR)"
            value={filters.minPrice}
            onChange={handleFilterChange}
            className="input-field"
          />

          <input
            type="number"
            name="maxPrice"
            placeholder="Max Fare (INR)"
            value={filters.maxPrice}
            onChange={handleFilterChange}
            className="input-field"
          />

          <input
            type="number"
            name="minSeats"
            placeholder="Min Seats"
            value={filters.minSeats}
            onChange={handleFilterChange}
            className="input-field"
          />

          <select
            value={sortBy}
            onChange={(e) => {
              setSortBy(e.target.value)
              setPage(1)
            }}
            className="input-field"
          >
            <option value="date">Sort by Date</option>
            <option value="price">Sort by Fare</option>
            <option value="seats">Sort by Seats</option>
          </select>

          <button type="submit" className="btn-primary">
            Search
          </button>
        </form>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>
      )}

      {loading ? (
        <Loading />
      ) : rides.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg">No rides found</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {rides.map((ride) => (
            <div key={ride._id} className="card">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex gap-4 items-center mb-2">
                    <h3 className="text-lg font-bold">{ride.from} to {ride.to}</h3>
                    <span className={`badge badge-${ride.status === 'active' ? 'success' : 'warning'}`}>
                      {ride.status}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-2">
                    {new Date(ride.departureDate).toLocaleDateString('en-IN')} at {ride.departureTime}
                  </p>
                  <p className="text-gray-600">Driver: {ride.driver.name}</p>
                  <div className="flex gap-4 mt-2 text-sm">
                    <span>Rating: {ride.driver.rating || 'N/A'}</span>
                    <span>{ride.availableSeats}/{ride.totalSeats} seats</span>
                    <span>Fare {formatINR(ride.pricePerSeat)}</span>
                  </div>
                </div>
                <Link to={`/ride/${ride._id}`} className="btn-primary ml-4">
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default SearchRides

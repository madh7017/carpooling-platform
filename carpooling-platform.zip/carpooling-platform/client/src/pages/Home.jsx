import { Link } from 'react-router-dom'
import { useAuth } from '@context/AuthContext'

const Home = () => {
  const { user } = useAuth()

  const highlights = [
    { title: 'Lower Travel Cost', desc: 'Split fuel and tolls for intercity rides', metric: 'Up to 65% savings' },
    { title: 'Verified Community', desc: 'Travel with rated drivers and trusted passengers', metric: 'Profile-based trust' },
    { title: 'Fast Booking', desc: 'Search, compare and reserve in under a minute', metric: 'Real-time availability' },
  ]

  const coverage = ['Bengaluru', 'Chennai', 'Hyderabad', 'Kochi', 'Coimbatore', 'Mysuru', 'Vijayawada', 'Madurai']

  return (
    <div className="pb-16">
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-br from-blue-700 via-blue-600 to-cyan-500 py-20 text-white sm:py-24">
        <div className="absolute -right-20 top-8 h-60 w-60 rounded-full bg-white/10 blur-3xl"></div>
        <div className="absolute -left-20 bottom-6 h-56 w-56 rounded-full bg-cyan-200/20 blur-3xl"></div>

        <div className="container-main relative z-10">
          <div className="max-w-3xl">
            <p className="mb-4 inline-flex rounded-full border border-white/30 bg-white/15 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
              Built for India
            </p>
            <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-6xl">
              A Better Way to Travel Between Indian Cities
            </h1>
            <p className="mt-5 max-w-2xl text-base text-blue-100 sm:text-lg">
              CarPool India helps drivers fill empty seats and helps passengers find safe, affordable, on-time rides.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              {!user ? (
                <>
                  <Link to="/register" className="btn-lg rounded-xl border border-white bg-white px-6 py-3 font-semibold text-blue-700 transition hover:bg-blue-50">
                    Create Account
                  </Link>
                  <Link to="/search-rides" className="btn-outline btn-lg border-white/70 bg-transparent px-6 py-3 text-white hover:bg-white/10">
                    Search Rides
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/search-rides" className="btn-lg rounded-xl border border-white bg-white px-6 py-3 font-semibold text-blue-700 transition hover:bg-blue-50">
                    Find a Ride
                  </Link>
                  {user.role === 'driver' && (
                    <Link to="/create-ride" className="btn-outline btn-lg border-white/70 bg-transparent px-6 py-3 text-white hover:bg-white/10">
                      Offer a Ride
                    </Link>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="container-main -mt-10 grid gap-4 sm:grid-cols-3">
        {highlights.map((item) => (
          <article key={item.title} className="card card-hover bg-white/95 backdrop-blur">
            <p className="text-xs font-semibold uppercase tracking-wide text-blue-600">{item.metric}</p>
            <h3 className="mt-2 text-lg font-bold text-slate-900">{item.title}</h3>
            <p className="mt-1 text-sm text-slate-600">{item.desc}</p>
          </article>
        ))}
      </section>

      <section className="container-main mt-14 grid items-start gap-8 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <div className="card">
            <h2 className="heading-3">Why riders choose CarPool India</h2>
            <p className="mt-2 text-muted">Practical features designed for frequent city-to-city travel.</p>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-sm font-semibold text-slate-900">Flexible trip options</p>
                <p className="mt-1 text-sm text-slate-600">One-way, weekend commute, and recurring rides for regular routes.</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-sm font-semibold text-slate-900">Clear fare visibility</p>
                <p className="mt-1 text-sm text-slate-600">Know fare per seat before you book, with transparent totals.</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-sm font-semibold text-slate-900">Reliable availability</p>
                <p className="mt-1 text-sm text-slate-600">Live seat counts help you avoid uncertainty while planning.</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <p className="text-sm font-semibold text-slate-900">Trust and accountability</p>
                <p className="mt-1 text-sm text-slate-600">Rating and booking history build confidence for both sides.</p>
              </div>
            </div>
          </div>
        </div>

        <aside className="lg:col-span-2">
          <div className="card bg-slate-900 text-white">
            <p className="text-sm uppercase tracking-wide text-cyan-300">Popular Coverage</p>
            <h3 className="mt-2 text-xl font-bold">Cities currently active</h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {coverage.map((city) => (
                <span key={city} className="rounded-full border border-slate-700 bg-slate-800 px-3 py-1 text-xs text-slate-100">
                  {city}
                </span>
              ))}
            </div>
            <p className="mt-4 text-sm text-slate-300">More routes are added as driver activity grows in each region.</p>
          </div>
        </aside>
      </section>
    </div>
  )
}

export default Home

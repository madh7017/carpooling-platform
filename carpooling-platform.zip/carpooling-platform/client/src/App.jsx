import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from '@context/AuthContext'
import ProtectedRoute from '@components/ProtectedRoute'
import Navbar from '@components/Navbar'
import Login from '@pages/Login'
import Register from '@pages/Register'
import Home from '@pages/Home'
import SearchRides from '@pages/SearchRides'
import RideDetail from '@pages/RideDetail'
import PassengerDashboard from '@pages/PassengerDashboard'
import DriverDashboard from '@pages/DriverDashboard'
import CreateRide from '@pages/CreateRide'
import MyBookings from '@pages/MyBookings'

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="app-shell">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/search-rides" element={<SearchRides />} />
            <Route path="/ride/:rideId" element={<RideDetail />} />
            
            <Route element={<ProtectedRoute />}>
              <Route path="/passenger-dashboard" element={<PassengerDashboard />} />
              <Route path="/my-bookings" element={<MyBookings />} />
              <Route path="/driver-dashboard" element={<DriverDashboard />} />
              <Route path="/create-ride" element={<CreateRide />} />
            </Route>
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </div>
      </AuthProvider>
    </Router>
  )
}

export default App
